# instructables-calculator
This is a git hub repository in reference to the instructable https://www.instructables.com/id/How-to-Make-Your-First-Simple-Software-Using-Pytho/

You may visit there to unterstand how softwares are made alos have the basic idea to make a simple calculator software
